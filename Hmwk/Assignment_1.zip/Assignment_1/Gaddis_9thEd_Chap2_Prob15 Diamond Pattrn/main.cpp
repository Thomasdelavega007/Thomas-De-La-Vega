
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/03/2023
 * Purpose: Create Diamond
 */

//System Libraries 
#include <iostream> //Input-Output Library 
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    
    //Initialize all variables
    
    //Process or Map solution
    
    //Display the output
    cout<<"   *"<<endl;
    cout<<"  ***"<<endl;
    cout<<" *****"<<endl;
    cout<<"*******"<<endl;
     cout<<" ***** "<<endl;
      cout<<"  ***   "<<endl;
       cout<<"   *    "<<endl;
    //Exit the program
    return 0;
}

