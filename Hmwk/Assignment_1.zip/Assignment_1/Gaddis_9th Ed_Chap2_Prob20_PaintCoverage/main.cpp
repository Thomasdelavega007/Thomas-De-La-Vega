
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/03/2023
 * Purpose: Find Number of cans needed
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
//Declare all Variables 
    unsigned short pntCov;
    unsigned short fncHt,fncLnth,nCans;
    
//Initailize all variables
    pntCov=340;
    fncHt=6;
    fncLnth=100;

//Process or map solutions
    nCans=4*fncHt*fncLnth/pntCov+1;//+1 for ceiling function round up 
    
// Display the output 
    cout<<"Paint Coverage = "<<pntCov<<" square feet/gallon"<<endl;
    cout<<"Fence Height  = "<<fncHt<<" Feet "<<endl;
    cout<<"Fence Length  = "<<fncLnth<<" Feet "<<endl;
    cout<<"Number off cans of paint   = "<<nCans<<"cans  "<<endl;
//Exit Program
    return 0;
}

