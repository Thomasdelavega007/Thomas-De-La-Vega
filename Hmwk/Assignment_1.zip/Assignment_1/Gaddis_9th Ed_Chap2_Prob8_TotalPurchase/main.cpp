
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/04/2023
 * Purpose: Total Purchase 
 */

//System Libraries 
#include <iostream> //Input-Output Library 
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    float I1,I2,I3,I4,I5;
    float SubTtl,AftrTax;
    
    //Initialize all variables
   //Price of items
    I1=15.95;
    I2=24.95;
    I3=6.95;
    I4=12.95;
    I5=3.95;
    
    //Process or Map solution
    SubTtl= I1+I2+I3+I4+I5;
    AftrTax= SubTtl + SubTtl*0.07; 
    
    //Display the output
    cout<<"Item 1 Price = $"<<I1<<endl;
     cout<<"Item 2 Price = $"<<I2<<endl;
      cout<<"Item 3 Price = $"<<I3<<endl;
       cout<<"Item 4 Price = $"<<I4<<endl;
        cout<<"Item 5 Price = $"<<I5<<endl;
    //SubTotal output 
    cout<<" Sub Total = $"<<SubTtl<<endl;
    cout<<" After Tax =$"<<AftrTax<<endl;
    //Exit the program
    return 0;
}

