
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/03/2023
 * Purpose: Write Sum
 */

//System Libraries 
#include <iostream> //Input-Output Library 
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    short a,b,total;
    //Initialize all variables
    a=100;
    b=50;
    //Process or Map solution
    total=a+b;
    //Display the output
    cout<<total<<" = "<<a<<" + "<<b<<endl;
    //or can be written like this 
    cout<<"     or"<<endl;
    cout<<a<<" + "<<b<<" = "<<endl;
    cout<<total<<endl;
    //Exit the program
    return 0;
}

