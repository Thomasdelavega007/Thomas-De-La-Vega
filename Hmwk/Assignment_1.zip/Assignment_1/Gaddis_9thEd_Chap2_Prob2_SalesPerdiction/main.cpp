
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Write Hello World
 */

//System Libraries 
#include <iostream> //Input-Output Library 
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    float EcPrcnt;
    int EcGen;
    int EcPerd;
    //Initialize all variables
    EcPrcnt=0.58;
    EcGen=8.6e6;
    //Process or Map solution
    EcPerd=0.58*8.6e6;
    //Display the output
    cout<<"East Coast Division will generate $"<<EcPerd<<" in sales.";
    //Exit the program
    return 0;
}

