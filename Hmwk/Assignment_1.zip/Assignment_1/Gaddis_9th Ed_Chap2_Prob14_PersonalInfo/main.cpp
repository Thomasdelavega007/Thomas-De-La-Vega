
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Write Hello World
 */

//System Libraries 
#include <iostream> //Input-Output Library 
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    
    //Initialize all variables
    
    //Process or Map solution
    
    //Display the output
    cout<<"Thomas De La Vega"<<endl;
     cout<<"8665 Lodgepole Ln, Riverside, California, 92508"<<endl;
      cout<<"(909)-561-8091"<<endl;
       cout<<"Electrical Engineering"<<endl;
    //Exit the program
    return 0;
}

