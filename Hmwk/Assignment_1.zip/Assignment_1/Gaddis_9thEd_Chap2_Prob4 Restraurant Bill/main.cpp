
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Write Hello World
 */

//System Libraries 
#include <iostream> //Input-Output Library 
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    float ResBll,Tax,Tip, TotalB;
    float Mealcst, TaxPerc,TipPerc;
    //Initialize all variables
    Mealcst=88.67;
    TaxPerc=0.0675;
    TipPerc=0.20;
    //Process or Map solution
    Tax=Mealcst*TaxPerc;
    Tip=(Mealcst+Tax)*TipPerc;
    TotalB=Mealcst+Tax+Tip;

    //Display the output
    cout<<"Meal Cost = $"<<Mealcst<<endl;
    cout<<"Tax Amount = $"<<Tax<<endl;
    cout<<"Tip Amount = $"<<Tip<<endl;
    cout<<"Total Bill = $"<<TotalB<<endl;
    //Exit the program
    return 0;
}

