
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/03/2023
 * Purpose: Find Miles Per Gallon
 */

//System Libraries 
#include <iostream> //Input-Output Library 
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    int Miles,Gallons,MPG;
    //Initialize all variables
    //Miles 
    Miles=375;
     Gallons=15;     
    //Process or Map solution
             MPG=Miles/Gallons;
    //Display the output
     cout<<"The number of miles per gallon this car gets is "<<MPG<<" mpg.";
    //Exit the program
    return 0;
}

