/* 
 * File:   main.cpp
 * Author: Thomas De La Vega
 * Created on 01/12/2024
 * Purpose:  Find bank charges 
 *          
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include<iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float Bal,Checks,ChkFee,MonFee,LwBFee,NewB; 
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
cout<<"Monthly Bank Fees"<<endl;
cout<<"Input Current Bank Balance and Number of Checks"<<endl;
cin>>Bal>>Checks; 

ChkFee=Checks<20? Checks*0.10:
        Checks<39? Checks*0.08:
        Checks<59? Checks*0.06:
        Checks>=60? Checks*0.04:0;

MonFee= 10;

LwBFee= Bal<400? 15:0;

NewB=Bal-ChkFee-MonFee-LwBFee;

cout<<fixed<<setprecision(2); 


cout<<"Balance     $"<<setw(9)<<Bal<<endl;
cout<<"Check Fee   $"<<setw(9)<<ChkFee<<endl;
cout<<"Monthly Fee $"<<setw(9)<<MonFee<<endl;
cout<<"Low Balance $"<<setw(9)<<LwBFee<<endl;
cout<<"New Balance $"<<setw(9)<<NewB;

    //Exit stage right or left!
    return 0;
}