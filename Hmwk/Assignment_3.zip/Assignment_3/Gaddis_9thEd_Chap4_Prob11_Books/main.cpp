/* 
 * File:   main.cpp
 * Author: Thomas De La Vega
 * Created on 01/14/2024
 * Purpose: Points for amounts of books 
 *          
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float Books, Points;
    
    //Initialize or input i.e. set variable values
   
   cout<<"Book Worm Points"<<endl;
   cout<<"Input the number of books purchased this month."<<endl;
   cin>>Books;
    
    //Display the outputs
cout<<"Books purchased =  "<<Books<<endl; 
   
    Points=Books==1? 5:
           Books==2? 15:
           Books==3? 30:
           Books>=4? 60:0;

cout<<"Points earned   = "<<Points;
   
    
    return 0;
}