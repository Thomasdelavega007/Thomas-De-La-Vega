/* 
 * File:   main.cpp
 * Author: Thomas De La Vega
 * Created on January , 8, 2024
 * Purpose:  Find max of diet coke cans to not die. 
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include<iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float C=453.592; // g/lbs
const float Mkm=5;//g
const float Mc=350;//g 
const float Cs=0.001; //consentration
const float Mm=35;//g 
//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float WD;
    int cans; 
    //Initialize or input i.e. set variable values
cin>>WD;
    
    //Map inputs -> outputs
   
cans= (WD*C*Mkm)/(Mc*Cs*Mm);

    //Display the outputs
cout<<"Program to calculate the limit of Soda Pop Consumption."<<endl;
cout<<"Input the desired dieters weight in lbs."<<endl; 
cout<<"The maximum number of soda pop cans"<<endl;
cout<<"which can be consumed is "<<cans<<" cans";
    //Exit stage right or left!
    return 0;
}