/* 
 * File:   main.cpp
 * Author: Thomas
 * Created on 01/10/1024
 * Purpose:  Determine and manage room compacity to avoid violation
 *           
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include<iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
     int RmCmp, NmbPpl, add, diff;
    //Initialize or input i.e. set variable values
   
  
   cout<<"Input the maximum room capacity and the number of people"<<endl;
    cin>>RmCmp>>NmbPpl; 
    diff=NmbPpl - RmCmp;
    add= RmCmp - NmbPpl;
    //Map inputs -> outputs
    if (NmbPpl>RmCmp){
    cout<<"Meeting cannot be held."<<endl;
    cout<<"Reduce number of people by "<<diff<<" to avoid fire violation.";
        
    }
    else {
        cout<<"Meeting can be held."<<endl;
        cout<<"Increase number of people by "<<add<<" will be allowed without violation.";
        
    }
    
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}