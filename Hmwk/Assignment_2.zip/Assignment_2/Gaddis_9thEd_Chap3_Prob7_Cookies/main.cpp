
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Calculate amount of calories 
 */

//System Libraries 
#include <iostream> //Input-Output Library 
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    int cookcnt,totcnt;
    
    //Initialize all variables
    
   
    //Display the output
    cout<<"Please enter below how many cookies you ate out if the 40 "
            "cookie bag."<<endl;
    cin>>cookcnt;
    
    //Process or Map solution
    
    //every 4 cookies gives 300 cal 
    //so that means 1 cookie gives 75 cal

    totcnt=cookcnt*75;

    cout<<"Total calories consumed are "<<totcnt<<endl;
    
    
    //Exit the program
    return 0;
}

