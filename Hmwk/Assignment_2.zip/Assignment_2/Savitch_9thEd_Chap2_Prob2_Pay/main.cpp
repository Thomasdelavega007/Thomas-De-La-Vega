/* 
 * File:   main.cpp
 * Author: Thomas De La Vega
 * Created on 01/10/2024
 * Purpose:  Determine Pay
 *           
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int PrvYSal; //Previous yearly salery 
   
    float NewYSal, //New yearly salery 
    PrcntIn, //percent increase
    NewMSal, // New monthly salery 
    RetroPy;// Retractive Pay
    
    //Initialize or input i.e. set variable values
    PrcntIn=.076;
    
    //Map inputs -> outputs
    
    cout<<"Input previous annual salary."<<endl;
    cin>>PrvYSal;
    cout<<setprecision(2)<<fixed;
    
   RetroPy=(PrcntIn* PrvYSal)/2; // divied by 2 becuase half od this is salery for 6 months 
    NewYSal=(PrcntIn*PrvYSal) + PrvYSal;
    NewMSal=NewYSal/12; 
    
    cout<<"Retroactive pay    = $  "<<RetroPy<<endl;
    cout<<"New annual salary  = $"<<NewYSal<<endl;
    cout<<"New monthly salary = $ "<<NewMSal; 
    
    //Display the outputs


    //Exit stage right or left!
    return 0;
}