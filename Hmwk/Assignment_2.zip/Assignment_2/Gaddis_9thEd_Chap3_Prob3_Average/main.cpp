
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/05/2023
 * Purpose: Find average grade
 */

//System Libraries 
#include <iostream> //Input-Output Library 
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    //Test scores
     float tstScr1,tstScr2,tstScr3,tstScr4,tstScr5;
    float ave;
    
    //Initialize all variables
   
    //Process or Map solution
  
    //Display the output
   cout<<"Please enter test percentage score #1 below "<<endl;
       cin>>tstScr1;
       cout<<endl;
     
   cout<<"Please enter test percentage score #2 below "<<endl;
       cin>>tstScr2;
       cout<<endl;
      
   cout<<"Please enter test percentage score #3 below "<<endl;
        cin>>tstScr3;
        cout<<endl;
        
   cout<<"Please enter test percentage score #4 below "<<endl;
        cin>>tstScr4;    
        cout<<endl;
   
   cout<<"Please enter test percentage score #5 below "<<endl;
        cin>>tstScr5;     
        cout<<endl;
        
  ave=(tstScr1+tstScr2+tstScr3+tstScr4+tstScr5)/5;  
 
   cout<<"Your average test score is "<<ave<<endl;
        
        
    //Exit the program
    return 0;
}

