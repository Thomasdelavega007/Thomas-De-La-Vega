
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/08/2023
 * Purpose: Convert temps
 */

//System Libraries 
#include <iostream> //Input-Output Library 

using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    float Finput, Coutput;
    //Initialize all variables
    
    //Process or Map solution
    
    //Display the output
    cout<<"Insert Fahrenheit Temperature:"<<endl;
    cin>>Finput;
    Coutput = (Finput-32)*5/9;
            cout<<"Celsius Temperature:"<<Coutput<<endl;
    //Exit the program
    return 0;
}

