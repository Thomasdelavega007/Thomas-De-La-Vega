/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/08/2023
 * Purpose: Calculate Pay Check 
 */

//System Libraries 
#include <iostream> //Input-Output Library 
#include<iomanip>
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    float PayRt, hrs; //Pay rate and hour worked
    float PayChck;// gross pay 
    //Initialize all variables
    
    //Display the output
    cin>>PayRt>>hrs;
  
  
    
     //Process or Map solution
    PayChck=PayRt*hrs;
    PayChck+=(hrs>40) ? PayRt*(hrs-40) : 0;
    
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"This program calculates the gross paycheck."<<endl;
    cout<<"Input the pay rate in $'s/hr and the number of hours."<<endl;
    cout<<"Paycheck = $"<<setw(7)<<PayChck;
    //Exit the program
    return 0;
}

