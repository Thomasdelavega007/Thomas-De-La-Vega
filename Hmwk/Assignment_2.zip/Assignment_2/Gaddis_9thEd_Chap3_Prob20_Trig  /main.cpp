
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Write Hello World
 */

//System Libraries 
#include <iostream> //Input-Output Library 
#include<cmath>
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    float Deg;
    float sinDeg,CosDeg,TanDeg;
    //Initialize all variables
    
    //Process or Map solution
    
    //Display the output
    cout<<"Please enter degree value below:"<<endl;
    cin>>Deg;
    cout<<"Sin = "<<sin(Deg*3.14/180)<<endl;
    cout<<"Cos = "<<cos(Deg*3.14/180)<<endl;
    cout<<"Tan = "<<tan(Deg*3.14/180)<<endl;
    //Exit the program
    return 0;
}

