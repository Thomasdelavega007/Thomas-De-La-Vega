
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Write Hello World
 */

//System Libraries 
#include <iostream> //Input-Output Library 
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    float rplcst, amtins;//Replacement cost and amount insured 
    //Initialize all variables
    
    //Process or Map solution
    
    //Display the output
    cout<<"Please enter your replacement cost below"<<endl;
    cin>>rplcst;
    amtins=rplcst*0.80;
    cout<<"Minimum amount of insurance: "<<amtins<<endl;
    
    //Exit the program
    return 0;
}

