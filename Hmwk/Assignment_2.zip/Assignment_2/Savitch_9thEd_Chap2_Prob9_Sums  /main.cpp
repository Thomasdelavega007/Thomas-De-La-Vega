
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Write Hello World
 */


//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int SumP,SumN,x;
    //Initialize or input i.e. set variable values
    cin>> x;
   SumP=(x>0)? SumP+x: 0;
   SumN=(x<0)? SumN+x: 0; 
   
    cin>>x;
   SumP=(x>0)? SumP+x: 0;
   SumN=(x<0)? SumN+x: 0; 
   
    cin>>x;
   SumP=(x>0)? SumP+x: 0;
   SumN=(x<0)? SumN+x: 0; 
   
    cin>>x;
   SumP=(x>0)? SumP+x: 0;
   SumN=(x<0)? SumN+x: 0; 
   
    cin>>x;
   SumP=(x>0)? SumP+x: 0;
   SumN=(x<0)? SumN+x: 0; 
   
    cin>>x;
   SumP=(x>0)? SumP+x: 0;
   SumN=(x<0)? SumN+x: 0; 
   
    cin>>x;
   SumP=(x>0)? SumP+x: 0;
   SumN=(x<0)? SumN+x: 0; 
   
    cin>>x;
   SumP=(x>0)? SumP+x: 0;
   SumN=(x<0)? SumN+x: 0; 
   
    cin>>x;
   SumP=(x>0)? SumP+x: 0;
   SumN=(x<0)? SumN+x: 0; 
   
    cin>>x;
   SumP=(x>0)? SumP+x: 0;
   SumN=(x<0)? SumN+x: 0; 
    //Map inputs -> outputs
    
    //Display the outputs
cout<<SumP<<endl;
cout<<SumN<<endl;

    //Exit stage right or left!
    return 0;
}