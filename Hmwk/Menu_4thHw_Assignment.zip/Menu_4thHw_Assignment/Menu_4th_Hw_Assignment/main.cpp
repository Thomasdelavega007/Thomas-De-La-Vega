
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/21/2024
 * Purpose: Write menu for assignment 4
 */

//System Libraries 
#include <iostream>  //Input/Output Library
#include <iomanip>
#include <string>
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    char choice;
    
    //Initialize all variables
    cout<<"Which Problem would you like to run"<<endl; 
    cout<<"1.  Problem 1 Sum"<<endl;
    cout<<"2.  Problem 2 PayInPennies"<<endl;
    cout<<"3.  Problem 3 MinMax"<<endl;
    cout<<"4.  Problem 4 Rectangle"<<endl;
    cout<<"5.  Problem 5 Pattern"<<endl;
    cout<<"6.  Problem 6 MPG"<<endl;
    cout<<"7.  Problem 7 FuelEff"<<endl;
    cout<<"8.  Problem 8 Inflation"<<endl;
    cout<<"9.  Problem 9 EstCost"<<endl;
    cout<<"10. Problem 10 2or3Max"<<endl;
    
    
    cin>>choice;
     
     //Process or Map sol
     // execute the menu/problem number
     switch(choice){
         case '1':{ cout<<endl<<"You are in Problem 1 Sum "<<endl; 
         
         //Declare Variables
    int sum,Dnumber;
    //Initialize or input i.e. set variable values
    
    sum=0; 
    //Map inputs -> outputs
    
    //Display the outputs

cin>>Dnumber;

for(int i=1;i<=Dnumber;i++){
   sum= sum + i;//sum=sum+i 
}

   cout<<"Sum = "<<sum;
         
         break;}
        
         case '2':{ cout<<endl<<"You are in Problem 2 PayInPennies "<<endl;
         
          //Declare Variables
    unsigned int PayPDay, PaySum;
    unsigned short NumDays;
    //Initialize or input i.e. set variable values
    PayPDay=1;
    PaySum=0;
    cin>>NumDays;
    
    
    //Map inputs -> outputs
    for(int day=1; day<=NumDays; day++){
        PaySum+=PayPDay;
        PayPDay*=2;
    }
    
    //Display the outputs
int dollar=PaySum/100;
int penny=PaySum%100;
cout<<"Pay = $"<<dollar<<"."<<((penny<10)? "0":"")<<penny;
         
         break;}
         
         case '3':{ cout<<endl<<"You are in Problem 3 MinMax"<<endl; 
         
         //Declare Va
    int Min, Max, num, count; 
    
    //Initialize or input i.e. set variable values
    
    Min=Max=0;
    num=0;
    
    
    count=0;
    
    do {
        cin>>num;
        
        if(count==0)
        Max=Min=num;
        
        if (num!=-99 && num<Min)
        Min=num;
        if (num!=-99 && num>Max)
        Max=num;
        
        count++;
        
    } while (num!=-99);
    
    cout<<"Smallest number in the series is "<<Min<<endl;
    cout<<"Largest  number in the series is "<<Max; 
         
         break;}
         
         case '4':{ cout<<endl<<"You are in Problem 4 Rectangle"<<endl;
         
         //Declare Variables
    char Letter;
    int i,count,num;
    //Initialize or input i.e. set variable values
    
    count=0;
    
    //Map inputs -> outputs
   cin>>num>>Letter;
   
  do {
      
       for(int i=0; i<num;i++)
       cout<<Letter;
       cout<<endl;
       
       count++;
  }while(count<num-1);

 for(int i=0; i<num;i++)
       cout<<Letter;
         
         break;}
         
         case '5':{ cout<<endl<<"You are in Problem 5 Pattern"<<endl; 
         
          //Declare Variables
    int out;
    
    //Initialize or input i.e. set variable values
   cin>>out;
   
    for(int i=1;i<=out;i++) { //i is number of rows and out is symbols outputted 
    
    for (int out=0;out<i;out++){
        cout<<'+';
        }
        cout<<endl;
        cout<<endl;
    }
    

//descnding now, an whole nother loop 
     for(int i=out;i>1;i--){
    
    for (int out=0;out<i;out++)
    {
        cout<<'+';
        }
        cout<<endl;
        cout<<endl;
    }
    cout<<'+';
         
         break;}
         
         case '6':{ cout<<endl<<"You are in Problem 6 MPG "<<endl; 
         
           //Declare Variables

    int count;
    float liter, input, gallons, miles, mpg;
    char Letter;
    
    //Initialize or input i.e. set variable values
    liter = 0.264179;
    
    //Map inputs -> outputs
   
    //Display the outputs



do{

cout<<fixed<<setprecision(2);
cout<<"Enter number of liters of gasoline:"<<endl;
cin>>input;
gallons = input*liter;
cout<<endl;

cout<<"Enter number of miles traveled:"<<endl;
cin>>miles>>Letter;
cout<<endl;

cout<<"miles per gallon:"<<endl;
mpg = miles/gallons;
cout<<mpg<<endl;
cout<<"Again:"<<endl;

count++;

if (count<=1)
cout<<endl;

}while(Letter!='n');

         
         break;}
         
         case '7':{ cout<<endl<<"You are in Problem 7 FuelEff"<<endl;
         
          //Declare Variables

    int count;
    float liter, input, gallons, miles, mpg, input2,gallons2,miles2,mpg2;
    char Letter1;
    
    float eff;
    
    //Initialize or input i.e. set variable values
    liter = 0.264179;
    
    //Map inputs -> outputs
   
    //Display the outputs



do{

cout<<fixed<<setprecision(2);


cout<<"Car 1"<<endl;
cout<<"Enter number of liters of gasoline:"<<endl;
cin>>input;
gallons = input*liter;


cout<<"Enter number of miles traveled:"<<endl;
cin>>miles;


cout<<"miles per gallon: ";
mpg = miles/gallons;
cout<<mpg<<endl;
cout<<endl;


cout<<"Car 2"<<endl;
cout<<"Enter number of liters of gasoline:"<<endl;
cin>>input2;
gallons2 = input2*liter;


cout<<"Enter number of miles traveled:"<<endl;
cin>>miles2>>Letter1;


cout<<"miles per gallon: ";
mpg2 = miles2/gallons2;
cout<<mpg2<<endl;


count++;

if (count<=2){

if (mpg>mpg2){
   cout<<endl;
    cout<<"Car 1 is more fuel efficient"<<endl;
    cout<<endl;
  }

if(mpg2>mpg){
cout<<endl;
cout<<"Car 2 is more fuel efficient"<<endl;
cout<<endl;
  }
  
cout<<"Again:"<<endl;
if(count<=1)
cout<<endl;

}


}while(Letter1!='n');
         
         break;}
         
         case '8':{ cout<<endl<<"You are in Problem 8 Inflation"<<endl;
         //idk 
         break;}
         case '9':{ cout<<endl<<"You are in Problem 9 EstCost"<<endl;
         //idk
         break;}
         
         case '10':{ cout<<endl<<"You are in Problem 10 2or3Max"<<endl; 
         
          //Declare Variables
    float num1,num2,num3;
    
    
    //Initialize or input i.e. set variable values
  
 
  
    cin>>num1>>num2>>num3;
    //Map inputs -> outputs
    cout<<"Enter first number:"<<endl;
    cout<<endl;
    
    cout<<"Enter Second number:"<<endl;
    cout<<endl;
    
    cout<<"Enter third number:"<<endl;
    cout<<endl;
    
    if(num1>num2){
    cout<<"Largest number from two parameter function:"<<endl;
    cout<<num1<<endl;
    cout<<endl;
    }
   
    if(num2>num1) {
    cout<<"Largest number from two parameter function:"<<endl;
    cout<<num2<<endl;
    cout<<endl;
    }

  
 
 if(num1>=num3 && num1>=num2){
 cout<<"Largest number from three parameter function:"<<endl;
 cout<<num1<<endl;}

 
 if (num2 > num1 && num2 > num3){
 cout<<"Largest number from three parameter function:"<<endl;
 cout<<num2<<endl;}
 
 
 if (num3>num2 && num3>num1){
 cout<<"Largest number from three parameter function:"<<endl;
 cout<<num3<<endl;}
         
         break;}
  
         default:{ cout<<endl<<"Exiting Menu"<<endl;}
     }
       
     
     cout<<endl<<"end of menu"<<endl;
    //Exit the program
    return 0;
}

