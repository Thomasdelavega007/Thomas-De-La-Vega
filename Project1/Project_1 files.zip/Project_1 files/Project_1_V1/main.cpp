
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Write Hello World
 */

//System Libraries 
#include <iostream> //Input-Output Library 
#include <string>
#include<iomanip>
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    int Bet, Sum, total;
    char guess;
    unsigned short Cguess; 
    
    //Initialize all variables
    total=10;
    
    
    //Process or Map solution
    do {
    cout<<" This game is called Odds and Evens"<<endl;
    cout<<endl;
    cout<<"You have 10 marbles. Place bet of your marbles by entering"<<
            "a number from 1-10: ";
    cin>>Bet;
   
    cout<<endl;
    
    cout<<"Now guess E for Even and O for Odd: ";
    cin>>guess;
    cout<<endl;
    
     Cguess=rand()%10;//[1,10]
    
    Cguess==1? 'O':
    Cguess==2? 'E':
    Cguess==3? 'O':
    Cguess==4? 'E':
    Cguess==5? 'O':
    Cguess==6? 'E':
    Cguess==7? 'O':
    Cguess==8? 'E':
    Cguess==9? 'O':
    Cguess==10?'E':0;
   
  if (guess!=Cguess)  
      total=total-Bet;
    cout<<"Your number of marble remaining is"<<total;
    
    cout<<endl;
    
     if (guess==Cguess)  
      total=total+Bet;
    cout<<"You now have "<<total<<" number of marbles."<<endl;
    cout<<endl;
    cout<<"Reach a total of 20 marbles and YOU WIN!"<<endl;
    
    
   
    
    } while(total>=0);
    //Display the output
    
    //Exit the program
    return 0;
}

