
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Write Hello World
 */

//System Libraries 
#include <iostream> //Input-Output Library 
#include <string>
#include<iomanip>
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    int Bet, Sum, total;
    int guess;
    int Cguess; 
    
    //Initialize all variables
    total=10;
    
    
    //Process or Map solution
   
    cout<<" This game is called Odds and Evens"<<endl;
    cout<<endl;
    cout<<"The objective is to win 10 marbles from your opponent to"<<
            " reach 20 marbles in total by "<<endl;
           cout<< "guessing if their bet is "<<
            "even or odd while betting your own marbles with each guess."<<endl;
    
    cout<<endl;
    cout<<"You have 10 marbles."<<endl;
   
    
    
    cout<<"Place bet of your marbles by entering"<<
            " a number from 1-10: ";
    cin>>Bet;
   
    cout<<endl;
    
    cout<<"Now guess Player 2's bet."<<
            " Input E for Even or O for Odd: ";
    cin>>guess;
    cout<<endl;
    
     Cguess=rand()%100;//[1,10]
     
    Cguess=='1'? 'O':
    Cguess=='2'? 'E':
    Cguess=='3'? 'O':
    Cguess=='4'? 'E':
    Cguess=='5'? 'O':
    Cguess=='6'? 'E':
    Cguess=='7'? 'O':
    Cguess=='8'? 'E':
    Cguess=='9'? 'O':
    Cguess=='10'?'E':0;
    
    cout<<endl;
    cout<<Cguess<<endl;
    cout<<endl;
   
  if (guess!=Cguess)  
      total=total-Bet;
    cout<<"Uh oh your guess was incorrect to the bet of player 2."<<endl;
    cout<<"Therefore you lost "<<Bet<<" marbles."<<endl;
    
    cout<<endl;
    
    total<=0? 0:0; 
    
    cout<<"Your number of marbles remaining is "<<total<<endl;
    cout<<endl;
    
    
     if (guess==Cguess){
    total=total+Bet;
    total>=20? 20:0;
        
    cout<<"You now have "<<total<<" marbles."<<endl;
    cout<<endl;
    cout<<"Reach a total of 20 marbles and YOU WIN!"<<endl;}
    
    
    
  
    //Display the output
    
    //Exit the program
    return 0;
}

