
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/26/2023
 * Purpose: Even or Odds Game 
 */

//System Libraries 
#include <iostream> //Input-Output Library 
#include <string> //string Library
#include<iomanip>//iomanipulation library
#include <cmath>//Math Library
#include <fstream>
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    srand(static_cast<unsigned int>(time(0)));
    
    // Declare all variables
    int Bet, gg; 
    int total;//total marbles 
    char guess;//Player guess
    char Cguess; //computer guess
    int count;
    string msg;
    float Winrate;//Win Rate
   
    //Initialize all variables
    total=10;
    count=1;
    gg=1;
    //Process or Map solution
   
    //Game name and instructions
    cout<<setw(40)<<" This game is called Odds and Evens"<<endl;
    cout<<endl;
    cout<<"The objective is to win 10 marbles from your opponent to"<<
    " reach 20 marbles in total by "<<endl;
    cout<< "guessing if their bet is "<<
    "even or odd while betting your own marbles with each guess."<<endl;
   //divider to organize turns/rounds for every guess 
    cout<<"__________________________________________________"<<
                   "__________________________________________"<<endl;
    

    
    cout<<endl;
    //Set 10 marbles. Each player has initially 10 marbles 
    cout<<setw(20)<<"You have 10 marbles."<<endl;
 
    //for loop to have game going on while toatl is from 1-20
for( int total=10; total>0 && total<20;){
       //counter for turns to output certain comments 
    gg++;
        
        cout<<"Place bet of your marbles by entering"<<
                " a number from 1-10: ";
        //input marbles being betted 
        cin>>Bet;
       
        //validating user input with if statement and d while loop
        //cannot bet 0 marbles
        if (Bet==0){
        do {
            cout<<"Invalid input. Cannot bet zero marbles."<<endl;
            cout<<"Try again but input a number from 1-10: ";
            cin>>Bet;
           } while(Bet==0);
        }
        
        
        cout<<endl;
//player 2's bet is a random number from 1-10. Goal is to guess what their bet will be 
        cout<<"Now guess Player 2's bet."<<
                " Input E for Even or O for Odd: ";
        cin>>guess;
        fstream Pg;
       //open file Pg
        Pg.open("Pg.dat", ios::out);
       //Output guess from file
        Pg<<guess;
        //Input value to be stored in file
        Pg>>guess;
       //computer guess of random number from 1-10
        Cguess=rand()%10+1;//[1,10]

        //clasifies if computer guess is even or odd 
        //depending on value fo computers guess
        char x = Cguess==1?'O':
                 Cguess==2? 'E':
                 Cguess==3? 'O':
                 Cguess==4? 'E':
                 Cguess==5? 'O':
                 Cguess==6? 'E':
                 Cguess==7? 'O':
                 Cguess==8? 'E':
                 Cguess==9? 'O':
                            'E';

        
      string Wx;//Stnads for full word of x instead of a single charecter 
      string Wg;//Stnads for full word of guess instead of a single charecter 
        
      //switch case to determine when to output the string of O and string of E
      //which is Odd and Even 
        switch(x)
        {
            case'O':Wx= x=='O'? "Odd":"Odd";
            case 'E': Wx=  x=='E'? "Even":"Odd";
                    
        }
        switch(guess){
            case'O':Wg= guess=='O'? "Odd":"Odd";
            case 'E': Wg=  guess=='E'? "Even":"Odd";
               
   
        }
// Make player known of whats happening in the game right now
        // let player know their bet, guess, and opponents guess. 
        cout<<endl;
        cout<<"Your bet = "<<Bet<<" marbles and your guess is "<<Wg<<endl;
        cout<<"Player 2's bet was "<<Wx<<endl;
        cout<<endl;

//guess is not eqaul to bet of player two 
      if (guess!=x){  
         //total subtracts the previous total minus current bet
          total=total-Bet;
          //check if total is 0 meaning player has zero marbles left to bet 
          if (total<=0){
                  msg="LOSER! YOU LOST ALL YOUR MARBLES! L's !!!!!";
                  msg = static_cast<string>(msg);
                  cout<<endl;
                  cout<<msg<<endl;
                  cout<<endl;
                  cout<<"You have zero marbles left."<<endl;
                  cout<<endl;
                  // Provides alt commnets in certain rounds of program 
                         if(gg==2)
                         cout<<"Dang you suck! :)"<<endl;
                         //alterntae comment    
                         else if (gg>=2)
                                cout<<"Game Over :) "<<endl;
                                cout<<endl;
                  
         } else{
// let player one happen what happned after their bet is lost
                  cout<<"Uh oh your guess was incorrect to the bet of player 2."<<endl;
                  cout<<"Therefore you lost "<<Bet<<" marbles."<<endl;
                  cout<<endl;
                  cout<<"Your number of marbles remaining is "<<total<<endl;
                  cout<<endl;
                }
                  count++;
              //divider for end of round and beginig of new round    
                 cout<<"__________________________________________________"<<
                   "____________________________________________"<<endl;
      
                 
                
          }


         if (guess==x){
          //total is calulated and absolute value is taken to be sure 
             //total can never be negative 
             total=abs(total+Cguess);
             //win rate calculared in order to check off float requirement 
           Winrate=(total/count)*10;
          //Total amount of marbles are max 20 and become a set 20 from this bool 
           if (total>=20){
                  msg="Congratulations! YOU WIN!";
                  msg = static_cast<string>(msg);
                  cout<<endl;
                  //use string variable 
                  cout<<msg<<endl;
                  cout<<endl;
                  cout<<"You gained all your opponents marbles."<<endl;
                  cout<<endl;
                  cout<<"Your win rate was "<<Winrate<<"% chance"<<endl;
                 
                  //determine wording output at the end of each individual game 
                  //depending on the amount of rounds it took for game to be completed
                  // 1 gg is one round 
                  if(gg==2)
                         cout<<"That was a good game! :)"<<endl;
                            else if (gg>=2)
                                cout<<"Game Over :) "<<endl;
                                cout<<endl;
         } else{
                  //The guess is eqaul to player 2's bet and shares new total plust diffent set 
               // of comments 
                  cout<<"YOU CHOSE WISLEY! :) "<<endl;
                  cout<<endl;
                  cout<<"Player 2 bet "<<static_cast<int>(Cguess)<<" marbles."<<endl;
                  cout<<endl;
                  cout<<"Therefore you now have "<<total<<" marbles."<<endl;
                  cout<<endl;
                  cout<<"Reach a total of 20 marbles and YOU WIN!"<<endl;
              }
                  count++; 
                 
                   cout<<"__________________________________________________"<<
                   "____________________________________________"<<endl;
                 
               
                
         }
//close Pg file 
    Pg.close();
    }
   
      //Display the output
    
    //Exit the program
    return 0;
}