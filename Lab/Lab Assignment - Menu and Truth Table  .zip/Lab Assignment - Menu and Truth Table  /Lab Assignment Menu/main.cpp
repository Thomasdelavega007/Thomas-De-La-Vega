
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Write menu for assignment 3
 */

//System Libraries 
#include <iostream>  //Input/Output Library
#include <iomanip>
#include <string>
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    char choice;
    
    //Initialize all variables
    cout<<"Which Problem would you like to run"<<endl; 
    cout<<"1.  Problem 1 SortNames"<<endl;
    cout<<"2.  Problem 2 Books"<<endl;
    cout<<"3.  Problem 3 BankCharges"<<endl;
    cout<<"4.  Problem 4 Race"<<endl;
    cout<<"5.  Problem 5 ISP Bill"<<endl;
    cout<<"6.  Problem 6 RockPaperScissors"<<endl;
    cout<<"7.  Problem 7 Roman Conversion"<<endl;
    cout<<"8.  Problem 8 CompatibleSigns"<<endl;
    cin>>choice;
     
     //Process or Map sol
     // execute the menu/problem number
     switch(choice){
         case '1':{
    cout<<endl<<"You are in Problem 1 SortNames"<<endl;
         
    //Declare Variables
    string Name1, Name2, Name3;
    string FirstN, SecondN, ThirdN;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
cout<<"Sorting Names"<<endl;
cout<<"Input 3 names"<<endl;

cin>>Name1;
cin>>Name2;
cin>>Name3;

if(Name1<Name2 && Name1<Name3){
    FirstN=Name1;
    if(Name2<Name3){
         SecondN=Name2;
             ThirdN=Name3;
}

else{
    ThirdN=Name2;
    SecondN=Name3;
    }
}

else if(Name2<Name1 && Name2<Name3){
    FirstN=Name2;
    if(Name1<Name3){
        SecondN=Name1;
             ThirdN=Name3;
    }
    
    else{
        ThirdN=Name1;
        SecondN=Name3;
    }
}

else if (Name3<Name2 && Name3<Name1){
    FirstN=Name3;
    if(Name2<Name1){
        SecondN=Name2;
             ThirdN= Name1;
    }
    
    else{
        ThirdN=Name2;
        SecondN=Name1;
    }
}

cout<<FirstN<<endl;
cout<<SecondN<<endl;
cout<<ThirdN;
         
         break;
         }
         
         case '2':{
             cout<<endl<<"You are in Problem 2 Books"<<endl;
    //Declare Variables
    float Books, Points;
    
    //Initialize or input i.e. set variable values
   
   cout<<"Book Worm Points"<<endl;
   cout<<"Input the number of books purchased this month."<<endl;
   cin>>Books;
    
    //Display the outputs
cout<<"Books purchased =  "<<Books<<endl; 
   
    Points=Books==1? 5:
           Books==2? 15:
           Books==3? 30:
           Books>=4? 60:0;

cout<<"Points earned   = "<<Points;
             break;
         }
         
         case '3':{
             cout<<endl<<"You are in Problem 3 Bank Charges"<<endl;
              //Declare Variables
    float Bal,Checks,ChkFee,MonFee,LwBFee,NewB; 
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
cout<<"Monthly Bank Fees"<<endl;
cout<<"Input Current Bank Balance and Number of Checks"<<endl;
cin>>Bal>>Checks; 

ChkFee=Checks<20? Checks*0.10:
        Checks<39? Checks*0.08:
        Checks<59? Checks*0.06:
        Checks>=60? Checks*0.04:0;

MonFee= 10;

LwBFee= Bal<400? 15:0;

NewB=Bal-ChkFee-MonFee-LwBFee;

cout<<fixed<<setprecision(2); 


cout<<"Balance     $"<<setw(9)<<Bal<<endl;
cout<<"Check Fee   $"<<setw(9)<<ChkFee<<endl;
cout<<"Monthly Fee $"<<setw(9)<<MonFee<<endl;
cout<<"Low Balance $"<<setw(9)<<LwBFee<<endl;
cout<<"New Balance $"<<setw(9)<<NewB;
             break;}
         
         case '4':{
             cout<<endl<<"You are in Problem 4 Race"<<endl;
              //Declare Variables
    string Name1,Name2,Name3;
    
    string first,second,third; 
    
    float FirstT,SecondT,ThirdT,T1,T2,T3;
    
    //Initialize or input i.e. set variable values
   cout<<"Race Ranking Program"<<endl;
   cout<<"Input 3 Runners"<<endl;
   cout<<"Their names, then their times"<<endl;
   
    cin>>Name1>>T1;
    cin>>Name2>>T2;
    cin>>Name3>>T3;
    //Map inputs -> outputs
    
    if (T1<T2 && T1<T3){
        first=Name1;
        
        if(T2<T3){
            second=Name2;
            third=Name3;
            
            cout<<first<<"\t"<<setw(3)<<T1<<endl;
            cout<<second<<"\t"<<setw(3)<<T2<<endl;
            cout<<third<<"\t"<<setw(3)<<T3;
            
            
        }else{
            third=Name2;
            second=Name3;
            
            cout<<first<<"\t"<<setw(3)<<T1<<endl;
            cout<<second<<"\t"<<setw(3)<<T3<<endl;
            cout<<third<<"\t"<<setw(3)<<T2;
            
        }
   
    }else if (T2<T1 && T2<T3){
        first=Name2;
        if(T1<T3){
            second=Name1;
            third=Name3;
            
            cout<<first<<"\t"<<setw(3)<<T2<<endl;
            cout<<second<<"\t"<<setw(3)<<T1<<endl;
            cout<<third<<"\t"<<setw(3)<<T3;
            
        }else{
            third=Name1;
            second=Name3;
            
            cout<<first<<"\t"<<setw(3)<<T2<<endl;
            cout<<second<<"\t"<<setw(3)<<T3<<endl;
            cout<<third<<"\t"<<setw(3)<<T1;
            
        }
  
    }else if(T3<T2 && T3<T1){
        first=Name3;
        if(T2<T1){
            second=Name2;
            third=Name1;
            
            cout<<first<<"\t"<<setw(3)<<T3<<endl;
            cout<<second<<"\t"<<setw(3)<<T2<<endl;
            cout<<third<<"\t"<<setw(3)<<T1;
            
        }else{
            third=Name2;
            second=Name1;
            
            cout<<first<<"\t"<<setw(3)<<T3<<endl;
            cout<<second<<"\t"<<setw(3)<<T1<<endl;
            cout<<third<<"\t"<<setw(3)<<T2;
        }
    }
             break;
         }
        
         case '5':{
             cout<<endl<<"You are in Problem 5 ISP Bill"<<endl;
             //Declare Variables
    float hours,Bill; 
    char Package;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
    cout<<"ISP Bill"<<endl;
    cout<<"Input Package and Hours"<<endl;
    
    cin>>Package>>hours;
    
    //A package 
    
    if (Package=='A')
    Bill= hours<=10? hours*0.995:
          hours>10? 9.95 + (hours-10)*2:0;
   
   //B package
   if (Package=='B')
    Bill= hours<=20? hours*0.7475:
          hours>20? 14.95 + (hours-20)*1:0;
       
    //C Package 
    if (Package=='C')
   Bill=  hours<=744? 19.95:0; 
    
    cout<<setprecision(2)<<fixed; 
    cout<<"Bill = $ "<<Bill;
             break;
         }
        
         case '6':{
             cout<<endl<<"You are in Problem 6 RockPaperScissors"<<endl;
                //Declare Variables
    char Player1, Player2;
    
    
cout<<"Rock Paper Scissors Game"<<endl;
cout<<"Input Player 1 and Player 2 Choices"<<endl;
cin>>Player1>>Player2;

     Player1-=Player1>=97? 32:0;
    Player2-=Player2>=97?32:0;
   
 
    if(Player1=='R'){
        if(Player2=='P') cout<<"Paper covers rock.";
        if(Player2=='S') cout<<"Rock breaks scissors.";
    }
    
    else if (Player1=='P'){
        if(Player2=='R') cout<<"Paper covers rock.";
        if(Player2=='S') cout<<"Scissors cuts paper.";
        
    }
    
    else if (Player1=='S'){
        if(Player2=='R') cout<<"Rock breaks scissors.";
        if(Player2=='P') cout<<"Scissors cuts paper.";
    }
             break;
         }
         
         case '7':{
             cout<<endl<<"You are in Problem 7 Roman Conversion"<<endl;
              //Declare Variables
    unsigned char n1,n10,n100,n1000;
    
    unsigned short x;
    
    string message;
    
    //Initialize or input i.e. set variable values
    cin>>x;
    message="";
    //Map inputs -> outputs
    if(x<1000 || x>3000){
        message=" is Out of Range!";
    }
    
    else {
    n1 = (x)%10;
    n10 = (x/10)%10;  
    n100 = (x/100)%10;    
    n1000 = (x/1000);
   
   //outputing Roman numerals in 1000's 
   switch(n1000){
       case 3:message+="M";
       case 2:message+="M";
       case 1:message+="M";
   };
   
   //100's 
   message+=n100==9? "CM":
            n100==8? "DCCC":
            n100==7? "DCC":
            n100==6? "DC":
            n100==5? "D":
            n100==4? "CD":
            n100==3? "CCC":
            n100==2? "CC":
            n100==1? "C":"";
            
//10's 
if(n10==9)message+="XC";
if (n10==8)message+="LXXX";
if (n10==7)message+="LXX";
if (n10==6)message+="LX";
if (n10==5)message+="L";
if (n10==4)message+="XL";
if (n10==3)message+="XXX";
if (n10==2)message+="XX";
if (n10==1)message+="X";


//1's 
 if(n10==9)message+="IX";
if (n10==8)message+="VIII";
if (n10==7)message+="VII";
if (n10==6)message+="VI";
if (n10==5)message+="V";
if (n10==4)message+="IV";
if (n10==3)message+="III";
if (n10==2)message+="II";
if (n10==1)message+="I";           
   
   
   message=" is equal to " + message;
    }

    //Display the outputs
cout<<"Arabic to Roman numeral conversion."<<endl;
cout<<"Input the integer to convert."<<endl;
cout<<x<<message;
             break;
         }
           
         case '8':{
             cout<<endl<<"You are in Problem 8 Compatible Signs"<<endl;
              //Declare Variables
    string sign1, sign2; 
    string element1, element2, Fire, Earth, Air, Water; 
    
    //Initialize or input i.e. set variable values
    cout<<"Horoscope Program which examines compatible signs."<<endl;
    cout<<"Input 2 signs."<<endl;
    
    cin>>sign1>>sign2; 
     
     element1 = sign1=="Aries"? "Fire":               
                sign1=="Leo"? "Fire":
                sign1=="Sagittarius"? "Fire":
                sign1=="Taurus"? "Earth":
                sign1=="Virgo"? "Earth":
                sign1=="Capricorn"? "Earth":
                sign1=="Gemini"? "Air":
                sign1=="Libra"? "Air":
                sign1=="Aquarius"? "Air":
                sign1=="Cancer"? "Water":
                sign1=="Scorpio"? "Water":
                sign1=="Pisces"? "Water":0;
                
    element2 = sign2=="Aries"? "Fire":                 
                sign2=="Leo"? "Fire":
                sign2=="Sagittarius"? "Fire":
                sign2=="Taurus"? "Earth":
                sign2=="Virgo"? "Earth":
                sign2=="Capricorn"? "Earth":
                sign2=="Gemini"? "Air":
                sign2=="Libra"? "Air":
                sign2=="Aquarius"? "Air":
                sign2=="Cancer"? "Water":
                sign2=="Scorpio"? "Water":
                sign2=="Pisces"? "Water":0;
     
    //Map inputs -> outputs
    if (element1==element2)
    cout<<sign1<<" and "<<sign2<<" are compatible "<<element1<<" signs.";
    
    if(element1!=element2)
    cout<<sign1<<" and "<<sign2<<" are not compatible signs.";
             break;
         }
         
         default:{ 
             cout<<endl<<"Exiting Menu"<<endl;
         }
     }
       
     
     cout<<endl<<"end of menu"<<endl;
    //Exit the program
    return 0;
}

