
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Write Hello World
 */

//System Libraries 
#include <iostream> //Input-Output Library 
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    bool x,y;
    //Top column of outputs
    cout<<"X Y !X !Y X||Y X&&Y X^Y X^Y^Y X^Y^X !(X && Y) !X||!Y !(X||Y) !X&&!Y" <<endl;
    
    //Process or Map solution
   
    //first row
    x=true;
    
    y=true;
    
    cout<<(x?'T':'F')<<" ";
    cout<<(y?'T':'F')<<"  ";
    cout<<(!x?'T':'F')<<"  ";
    cout<<(!y?'T':'F')<<"   ";
    cout<<(x&&y?'T': 'F')<<"    ";
    cout<<(x||y?'T':'F')<<"    ";    
    cout<<(x^y? 'T': 'F')<<"   ";
    cout<<(x^y^y? 'T': 'F')<<"      ";
    cout<<(x^y^x? 'T': 'F')<<"       ";
    cout<<(!(x&&y)? 'T': 'F')<<"      ";
    cout<<(!x||!y? 'T': 'F')<<"        ";
    cout<<(!(x||y)? 'T': 'F')<<"      ";
    cout<<(!x&&!y? 'T': 'F')<<endl;
    
    //second row
    y=false;
    cout<<(x?'T':'F')<<" ";
    cout<<(y?'T':'F')<<"  ";
    cout<<(!x?'T':'F')<<"  ";
    cout<<(!y?'T':'F')<<"   ";
    cout<<(x&&y?'T': 'F')<<"    ";
    cout<<(x||y?'T':'F')<<"    ";    
    cout<<(x^y? 'T': 'F')<<"   ";
    cout<<(x^y^y? 'T': 'F')<<"      ";
    cout<<(x^y^x? 'T': 'F')<<"       ";
    cout<<(!(x&&y)? 'T': 'F')<<"      ";
    cout<<(!x||!y? 'T': 'F')<<"        ";
    cout<<(!(x||y)? 'T': 'F')<<"      ";
    cout<<(!x&&!y? 'T': 'F')<<endl;
    
    //third row
    x=false;
    cout<<(x?'T':'F')<<" ";
    cout<<(y?'T':'F')<<"  ";
    cout<<(!x?'T':'F')<<"  ";
    cout<<(!y?'T':'F')<<"   ";
    cout<<(x&&y?'T': 'F')<<"    ";
    cout<<(x||y?'T':'F')<<"    ";    
    cout<<(x^y? 'T': 'F')<<"   ";
    cout<<(x^y^y? 'T': 'F')<<"      ";
    cout<<(x^y^x? 'T': 'F')<<"       ";
    cout<<(!(x&&y)? 'T': 'F')<<"      ";
    cout<<(!x||!y? 'T': 'F')<<"        ";
    cout<<(!(x||y)? 'T': 'F')<<"      ";
    cout<<(!x&&!y? 'T': 'F')<<endl;
    
    //fourth row
    x=false;
    y=false;
    cout<<(x?'T':'F')<<" ";
    cout<<(y?'T':'F')<<"  ";
    cout<<(!x?'T':'F')<<"  ";
    cout<<(!y?'T':'F')<<"   ";
    cout<<(x&&y?'T': 'F')<<"    ";
    cout<<(x||y?'T':'F')<<"    ";    
    cout<<(x^y? 'T': 'F')<<"   ";
    cout<<(x^y^y? 'T': 'F')<<"      ";
    cout<<(x^y^x? 'T': 'F')<<"       ";
    cout<<(!(x&&y)? 'T': 'F')<<"      ";
    cout<<(!x||!y? 'T': 'F')<<"        ";
    cout<<(!(x||y)? 'T': 'F')<<"      ";
    cout<<(!x&&!y? 'T': 'F')<<endl;
    
    
    //Display the output
    
    //Exit the program
    return 0;
}

