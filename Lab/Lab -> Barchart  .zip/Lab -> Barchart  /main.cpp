
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Write Hello World
 */

//System Libraries 
#include <iostream> //Input-Output Library 
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    int S1,S2,S3,S4,S5; 
    
    float I1,I2,I3,I4,I5;
    //Initialize all variables
    
    //Process or Map solution
    
    //Display the output
    
    cout<<"Enter today's sales for store 1: "<<endl;
    cin>>S1;
     cout<<"Enter today's sales for store 2: "<<endl;
    cin>>S2;
     cout<<"Enter today's sales for store 3: "<<endl;
    cin>>S3;
     cout<<"Enter today's sales for store 4: "<<endl;
    cin>>S4;
     cout<<"Enter today's sales for store 5: "<<endl;
    cin>>S5;
    
    cout<<"SALES BAR CHART (Each * =$100)"<<endl;
    
    I1=S1/100;
    I2=S2/100;
    I3=S3/100;
    I4=S4/100;
    I5=S5/100;
    
    cout<<"Store 1: ";
    for(int i=0;i<=I1;i++)
    {
        cout<<"*";
    }
    cout<<endl;
    
    cout<<"Store 2: ";
    for(int i=0;i<=I2;i++){
        cout<<"*";
    }
        cout<<endl;

    cout<<"Store 3: ";
    for(int i=0;i<=I3;i++){
        cout<<"*";
    }
            cout<<endl;

    cout<<"Store 4: ";
    for(int i=0;i<=I4;i++){
        cout<<"*";
    }
                cout<<endl;

    cout<<"Store 5: ";
    for(int i=0;i<=I5;i++){
        cout<<"*";
    }
    
    //Exit the program
    return 0;
}

