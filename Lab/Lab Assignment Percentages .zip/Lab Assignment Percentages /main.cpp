
/*
 *File: Main.cpp
 * Author: Thomas De La Vega
 * Created: 01/02/2023
 * Purpose: Write Hello World
 */

//System Libraries 
#include <iostream> //Input-Output Library 
# include <iomanip>
using namespace std;

//User Libraries 

//Global Constants - Math, Physics, Chem,Conversions

//Function Prototypes 

//Program Execution begins here
int main(int argc, char** argv) {
    //Set a random seed
    
    // Declare all variables
    float milBdgt,fedBdgt,mlPrcnt;
    
    //Initialize all variables
    milBdgt=7.0e11f;    //Military Budget = 700 Billion   

    fedBdgt=4.1e12f;    //Federal Budget  = 4.1 Trillion

    
   //Process or Map solution
    mlPrcnt=(milBdgt/fedBdgt)*100;
    
    //Display the output
    cout<<fixed<<setprecision(1);
    cout<<"Military budget is "<<mlPrcnt<<"% of the federal budget."<<endl;
    
    //Exit the program
    return 0;
}

